//Tiffany Wong and Andrew Rubesa psuedo-code for project 4.

//QR code generator app.

//1. Document ready
//2. Set up namespace qrApp:
//3. Init to start the function
//4. Pull user data from form with following parameters:
//a) User's portfolio URL.
//b) User's width.
//c) User's background color.
//5. Submission button for user to generate qrcode along with download button to allow user to download their qrcode locally.
//6. Make AJAX request to happi.dev to endpoint: https://api.happi.dev/v1/qrcode
//7. Generate the users qr code to the page based on users parameters.
